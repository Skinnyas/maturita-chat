// Komponenta chatu
// Tato komponenta spravuje hlavní logiku chatu

class Chat {
  constructor() {
    // Inicializace selektorů
    this.$messages = $('.messages-content');
    this.$messageInput = $('.message-input');
    this.$messageSubmit = $('.message-submit');
    
    this.initialize();
  }

  // Inicializace chatu
  initialize() {
    this.setupScroll();
    this.setupEventListeners();
    this.startFakeMessages();
  }

  // Nastavení scrollbaru
  setupScroll() {
    this.$messages.mCustomScrollbar();
  }

  // Nastavení posluchačů událostí
  setupEventListeners() {
    this.$messageSubmit.click(() => this.sendMessage());
    
    $(window).on('keydown', (e) => {
      if (e.which === 13) {
        this.sendMessage();
        return false;
      }
    });
  }

  // Spuštění generování falešných zpráv
  startFakeMessages() {
    setTimeout(() => this.fakeMessage(), 100);
  }

  // Odeslání zprávy
  sendMessage() {
    const message = this.$messageInput.val().trim();
    
    if (!message) return;

    this.addMessage(message, true);
    this.$messageInput.val('');
    
    // Odpověď po odeslání zprávy
    setTimeout(() => this.fakeMessage(), 1000 + (Math.random() * 20) * 100);
  }

  // Přidání zprávy do chatu
  addMessage(text, isPersonal = false) {
    const messageClass = isPersonal ? 'message-personal' : 'message';
    const $message = $(`<div class="message ${messageClass}">${text}</div>`);
    
    $message.appendTo($('.mCSB_container')).addClass('new');
    this.addTimestamp($message);
    this.updateScroll();
  }

  // Přidání časového razítka k zprávě
  addTimestamp($message) {
    const now = new Date();
    const minutes = now.getMinutes();
    
    if (this.lastMinute !== minutes) {
      this.lastMinute = minutes;
      $('<div class="timestamp">' + now.getHours() + ':' + minutes + '</div>')
        .appendTo($message);
    }
  }

  // Aktualizace scrollbaru
  updateScroll() {
    this.$messages.mCustomScrollbar("update").mCustomScrollbar('scrollTo', 'bottom', {
      scrollInertia: 10,
      timeout: 0
    });
  }

  // Generování falešné zprávy
  fakeMessage() {
    const messages = [
      'To je fakt super!',
      'Díky za odpověď!',
      'Už to mám!',
      'Jo, to je správně',
      'Díky za pomoc!',
      'To jsem nevěděl',
      'To je fakt zajímavé'
    ];

    const message = messages[Math.floor(Math.random() * messages.length)];
    this.addMessage(message);
  }
}

// Inicializace chatu po načtení stránky
$(window).load(() => new Chat());
