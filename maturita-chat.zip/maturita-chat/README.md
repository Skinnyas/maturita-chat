# Maturita Chat

Chatovací aplikace pro maturitní četbu

Tato aplikace slouží jako demo pro přímé zpravodajství mezi učiteli a studenty při přípravě na maturitní četbu.

## Funkce
- Moderní chatovací rozhraní
- Falešné odpovědi pro demo
- Plynulé animace a efekty
- Responsive design

## Technologie
- HTML5
- CSS3
- JavaScript
- jQuery
- Custom Scrollbar Plugin
