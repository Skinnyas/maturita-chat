var $messages = $('.messages-content'),
    d, h, m,
    i = 0;

$(window).load(function() {
  $messages.mCustomScrollbar();
  setTimeout(function() {
    fakeMessage();
  }, 100);
});

function updateScrollbar() {
  $messages.mCustomScrollbar("update").mCustomScrollbar('scrollTo', 'bottom', {
    scrollInertia: 10,
    timeout: 0
  });
}

function setDate(){
  d = new Date()
  if (m != d.getMinutes()) {
    m = d.getMinutes();
    $('<div class="timestamp">' + d.getHours() + ':' + m + '</div>').appendTo($('.message:last'));
  }
}

function insertMessage() {
  msg = $('.message-input').val();
  if ($.trim(msg) == '') {
    return false;
  }
  $('<div class="message message-personal">' + msg + '</div>').appendTo($('.mCSB_container')).addClass('new');
  setDate();
  $('.message-input').val(null);
  updateScrollbar();
  setTimeout(function() {
    fakeMessage();
  }, 1000 + (Math.random() * 20) * 100);
}

$('.message-submit').click(function() {
  insertMessage();
});

$(window).on('keydown', function(e) {
  if (e.which == 13) {
    insertMessage();
    return false;
  }
})

var Fake = [
   'Kdo je autorem díla a do jakého literárního období/směru patří?',
  'Kdy bylo dílo napsáno/vydáno a jaký je jeho historický kontext?',
  'Jaký je žánr díla a jeho základní charakteristika?',
  'Jaká je hlavní myšlenka/téma díla?',
  'Jaký má dílo vztah k ostatním dílům autora nebo k dobové literatuře?',
]

function fakeMessage() {
  if ($('.message-input').val() != '') {
    return false;
  }
  $('<div class="message loading new"><figure class="avatar"><img src="https://media.discordapp.net/attachments/912722787788029982/1373945861142478908/projekt_logo-2.png?ex=682c424b&is=682af0cb&hm=edd747677481408cabcdcf4d4fcea6f3c0eac41a154ea392f5c0a6694716ebeb&=" /></figure><span></span></div>').appendTo($('.mCSB_container'));
  updateScrollbar();

  setTimeout(function() {
    $('.message.loading').remove();
    $('<div class="message new"><figure class="avatar"><img src="https://media.discordapp.net/attachments/912722787788029982/1373945861142478908/projekt_logo-2.png?ex=682c424b&is=682af0cb&hm=edd747677481408cabcdcf4d4fcea6f3c0eac41a154ea392f5c0a6694716ebeb&=" /></figure>' + Fake[i] + '</div>').appendTo($('.mCSB_container')).addClass('new');
    setDate();
    updateScrollbar();
    i++;
  }, 1000 + (Math.random() * 20) * 100);

}